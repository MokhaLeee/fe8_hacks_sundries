# EAFormattingSuite
Suite for formatting different kinds of data into an insertable format through Event Assembler for GBAFE ROMhacking
